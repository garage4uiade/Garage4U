package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class log_in extends AppCompatActivity {

    EditText a1;
    EditText a2;
    boolean erro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a1=findViewById(R.id.txt_email);
        a2=findViewById(R.id.txt_pass);
        Intent getIntent = getIntent();
        erro = getIntent.getBooleanExtra("erro",false);
    }

    public void on_click(View v) {

        String texto [] = new String[2];
        texto[0] = a1.getText().toString();
        texto[1] = a2.getText().toString();
        Intent mainActivity = new Intent(getApplicationContext(), app_principal.class);
        mainActivity.putExtra("dados",texto);
        startActivity(mainActivity);
    }
    public void esqueci(View v) {


        String texto [] = new String[2];
        texto[0] = a1.getText().toString();
        texto[1] = a2.getText().toString();
        Intent mainActivity = new Intent(getApplicationContext(), esquecime_da_palavrapass.class);
        mainActivity.putExtra("dados",texto);
        startActivity(mainActivity);
    }
    public void cadastrar(View v) {


        String texto [] = new String[2];
        texto[0] = a1.getText().toString();
        texto[1] = a2.getText().toString();
        Intent mainActivity = new Intent(getApplicationContext(), cadastro.class);
        startActivity(mainActivity);
    }
}