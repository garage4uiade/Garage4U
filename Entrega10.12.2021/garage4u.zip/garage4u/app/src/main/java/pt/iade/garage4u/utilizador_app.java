package pt.iade.garage4u;

public class utilizador_app {
    private int id;
    private String email;
    private String nome;
    private String pass;

    public utilizador_app () {
        this.id = -1;
        this.email="";
        this.nome="";
        this.pass="";
    }
    public utilizador_app (int id, String email, String nome,String pass) {
        this.id = id;
        this.email=email;
        this.nome=nome;
        this.pass=pass;
    }

    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getNome() {
        return nome;
    }

    public String getPass() {
        return pass;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    @Override
    public String toString() {
        return "utilizador_app{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", nome='" + nome + '\'' +
                ", pass='" + pass + '\'' +
                '}';
    }
}
