package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class app_principal extends AppCompatActivity {

    String textovar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        //Intent getIntent = getIntent();
        //Intent inte = getIntent.getSerializableExtra("dados");
        //utilizador_app teste = (utilizador_app) inte.getExtras().getParcelable("dados");


    }
}