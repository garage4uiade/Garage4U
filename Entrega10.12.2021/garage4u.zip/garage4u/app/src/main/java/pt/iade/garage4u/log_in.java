package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import pt.iade.garage4u.Downloader.JSONarrayDownloader;
import pt.iade.garage4u.Downloader.JSONobjDownloader;

public class log_in extends AppCompatActivity {

    EditText a1;
    EditText a2;
    boolean erro;

    public ArrayList<String> routes;
    public ArrayList<String> routesId;
    public ArrayList<String> routesName;
    public ArrayAdapter<String> adapterRoutes;
    public JSONObject utiObj;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a1=findViewById(R.id.txt_email);
        a2=findViewById(R.id.txt_pass);
        Intent getIntent = getIntent();
        erro = getIntent.getBooleanExtra("erro",false);


        JSONobjDownloader obj = new JSONobjDownloader();

        try {
            utiObj = obj.execute("https://garage4u-bd.herokuapp.com/api/utilizador/1").get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }

        utilizador_app utilizador=new utilizador_app();
        try {
            utilizador = new utilizador_app(utiObj.getInt("utilizadorId"),utiObj.getString("utilizadorEmail"),utiObj.getString("utilizadorName"),utiObj.getString("utilizadorPass"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.e("dwa",utilizador.toString());




    }

    public void on_click(View v) {

        String texto[] = new String[2];
        texto[0] = a1.getText().toString();
        texto[1] = a2.getText().toString();


        JSONobjDownloader obj = new JSONobjDownloader();
        try {
            utiObj = obj.execute("https://garage4u-bd.herokuapp.com/api/utilizador/1").get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }
        if (utiObj != null) {
            utilizador_app utilizador = new utilizador_app();
            try {
                utilizador = new utilizador_app(utiObj.getInt("utilizadorId"), utiObj.getString("utilizadorEmail"), utiObj.getString("utilizadorName"), utiObj.getString("utilizadorPass"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Log.e("dwa", utilizador.toString());
            Intent mainActivity = new Intent(getApplicationContext(), app_principal.class);
            //mainActivity.putExtra("dados",utilizador);
            startActivity(mainActivity);

        }
        else
        {
            Toast.makeText(getApplicationContext(),"Erro",Toast.LENGTH_SHORT).show();
        }






        Intent mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
        mainActivity.putExtra("dados", texto);
        startActivity(mainActivity);
    }
    public void esqueci(View v) {


        String texto [] = new String[2];
        texto[0] = a1.getText().toString();
        texto[1] = a2.getText().toString();
        Intent mainActivity = new Intent(getApplicationContext(), esquecime_da_palavrapass.class);
        mainActivity.putExtra("dados",texto);
        startActivity(mainActivity);
    }
    public void cadastrar(View v) {


        String texto [] = new String[2];
        texto[0] = a1.getText().toString();
        texto[1] = a2.getText().toString();
        Intent mainActivity = new Intent(getApplicationContext(), cadastro.class);
        startActivity(mainActivity);
    }
}